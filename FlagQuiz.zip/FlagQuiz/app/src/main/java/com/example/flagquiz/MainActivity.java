package com.example.flagquiz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    AssetManager assets;
    TextView quesCount,answer;
    ImageView img;
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,rightAnswerBtn,chosen;
    ImageButton bNext;
    String []imageList;
    int nbCor=0,nbQuestion=1,choice=3;

    ArrayList<String> selectedRegions;
    boolean select[]={true,true,true,true};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        quesCount = (TextView)findViewById(R.id.questionTxt);
        answer = (TextView)findViewById(R.id.answerTxt);
        b1 = (Button)findViewById(R.id.b1);
        b2 = (Button)findViewById(R.id.b2);
        b3 = (Button)findViewById(R.id.b3);
        b4 = (Button)findViewById(R.id.b4);
        b5 = (Button)findViewById(R.id.b5);
        b6 = (Button)findViewById(R.id.b6);
        b7 = (Button)findViewById(R.id.b7);
        b8 = (Button)findViewById(R.id.b8);
        b9 = (Button)findViewById(R.id.b9);
        bNext = (ImageButton)findViewById(R.id.nextBtn);
        img = (ImageView)findViewById(R.id.img);

        bNext.setClickable(false);

        assets = this.getAssets();
        try{
            imageList = assets.list("png");
        } catch(IOException e) {
            e.printStackTrace();
        }
        selectedRegions = new ArrayList<String>();
        selectedRegions.add("Europe");
        selectedRegions.add("Asia");
        selectedRegions.add("America");
        selectedRegions.add("Africa");
        editButtons(choice);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        if(item.getItemId()==R.id.choix) {
            onClickShowAlert1();
        }
        if(item.getItemId()==R.id.region) {
            onClickShowAlert2();
            fillQuestion(choice);
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClickShowAlert1() {
        AlertDialog.Builder alertDialog = new
                AlertDialog.Builder(MainActivity.this);
        alertDialog.setMessage(R.string.alert_message1);
        alertDialog.setPositiveButton("9 choices", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
                choice=9;
                editButtons(choice);
            }
        });

        alertDialog.setNeutralButton("3 choices", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
                choice=3;
                editButtons(choice);
            }
        });

        alertDialog.setNegativeButton("6 choices", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
                choice=6;
                editButtons(choice);
            }
        });
        alertDialog.show();
    }

    public void onClickShowAlert2() {

        ArrayList selectedItems = new ArrayList();
        AlertDialog.Builder alertDialog = new
                AlertDialog.Builder(MainActivity.this);
        alertDialog.setTitle(R.string.alert_message2);
        alertDialog.setMultiChoiceItems(R.array.regions, select,
                new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which,
                                        boolean isChecked) {
                        if (isChecked) {
                            // If the user checked the item, add it to the selected items
                            selectedItems.add(which);
                            select[which]=true;
                        } else if (selectedItems.contains(which)) {
                            // Else, if the item is already in the array, remove it
                            selectedItems.remove(which);
                            select[which]=false;
                        }
                    }
                })
                // Set the action buttons
                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked OK, so save the selectedItems results somewhere
                        // or return them to the component that opened the dialog
                        fillQuestion(choice);
                    }
                })
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
        alertDialog.show();
    }

    public void reg(){
        if(select[0])
            selectedRegions.add("Europe");
        else
            selectedRegions.remove("Europe");
        if(select[1])
            selectedRegions.add("Asia");
        else
            selectedRegions.remove("Asia");
        if(select[2])
            selectedRegions.add("America");
        else
            selectedRegions.remove("America");
        if(select[3])
            selectedRegions.add("Africa");
        else
            selectedRegions.remove("Africa");
    }

    public void editButtons(int nb){
        switch (nb){
            case 3:
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);
                b7.setVisibility(View.INVISIBLE);
                b8.setVisibility(View.INVISIBLE);
                b9.setVisibility(View.INVISIBLE);
                break;
            case 6:
                b4.setVisibility(View.VISIBLE);
                b5.setVisibility(View.VISIBLE);
                b6.setVisibility(View.VISIBLE);
                b7.setVisibility(View.INVISIBLE);
                b8.setVisibility(View.INVISIBLE);
                b9.setVisibility(View.INVISIBLE);
                break;
            case 9:
                b4.setVisibility(View.VISIBLE);
                b5.setVisibility(View.VISIBLE);
                b6.setVisibility(View.VISIBLE);
                b7.setVisibility(View.VISIBLE);
                b8.setVisibility(View.VISIBLE);
                b9.setVisibility(View.VISIBLE);
        }
        nbQuestion=1;
        nbCor=0;
        fillQuestion(nb);
    }

    public void fillQuestion( int nbOfChoices){
        int rand=(int)((Math.random()*10)%nbOfChoices);
        String imageName;
        reg();
        do imageName = imageList[(int) (Math.random() * imageList.length)];
        while ( !(selectedRegions.contains(((imageName.split(".png")[0]).split("-"))[0])));
        String nomUneImage = "png/" + imageName; //contient le chemin du premier fichier
        Drawable image = null;
        try {
            image = Drawable.createFromStream(assets.open(nomUneImage), imageName);
        } catch (IOException e) {
            e.printStackTrace();
        }
        img.setImageDrawable(image);

        b1.setText((imageList[(int)(Math.random()*imageList.length)].split(".png"))[0]);
        b2.setText((imageList[(int)(Math.random()*imageList.length)].split(".png"))[0]);
        b3.setText((imageList[(int)(Math.random()*imageList.length)].split(".png"))[0]);
        if(nbOfChoices>3) {
            b4.setText((imageList[(int) (Math.random() * imageList.length)].split(".png"))[0]);
            b5.setText((imageList[(int) (Math.random() * imageList.length)].split(".png"))[0]);
            b6.setText((imageList[(int) (Math.random() * imageList.length)].split(".png"))[0]);
        }
        if(nbOfChoices>6) {
            b7.setText((imageList[(int) (Math.random() * imageList.length)].split(".png"))[0]);
            b8.setText((imageList[(int) (Math.random() * imageList.length)].split(".png"))[0]);
            b9.setText((imageList[(int) (Math.random() * imageList.length)].split(".png"))[0]);
        }

        switch(rand){
            case 0:
                b1.setText((imageName.split(".png"))[0]);
                rightAnswerBtn = b1;
                break;
            case 1:
                b2.setText((imageName.split(".png"))[0]);
                rightAnswerBtn = b2;
                break;
            case 2:
                b3.setText((imageName.split(".png"))[0]);
                rightAnswerBtn = b3;
                break;
            case 3:
                b4.setText((imageName.split(".png"))[0]);
                rightAnswerBtn = b4;
                break;
            case 4:
                b5.setText((imageName.split(".png"))[0]);
                rightAnswerBtn = b5;
                break;
            case 5:
                b6.setText((imageName.split(".png"))[0]);
                rightAnswerBtn = b6;
                break;
            case 6:
                b7.setText((imageName.split(".png"))[0]);
                rightAnswerBtn = b7;
                break;
            case 7:
                b8.setText((imageName.split(".png"))[0]);
                rightAnswerBtn = b8;
                break;
            case 8:
                b9.setText((imageName.split(".png"))[0]);
                rightAnswerBtn = b9;
                break;
        }

        quesCount.setText("Question "+nbQuestion+" out of 10");
        answer.setText("");
    }

    public void checkAnswer(View v) {
        chosen = (Button) findViewById(v.getId());
        if ((chosen == b1 && b1 == rightAnswerBtn) || (chosen == b2 && b2 == rightAnswerBtn) || (chosen == b3 && b3 == rightAnswerBtn) ||
                (chosen == b4 && b4 == rightAnswerBtn) || (chosen == b5 && b5 == rightAnswerBtn) || (chosen == b6 && b6 == rightAnswerBtn) ||
                (chosen == b7 && b7 == rightAnswerBtn) || (chosen == b8 && b8 == rightAnswerBtn) || (chosen == b9 && b9 == rightAnswerBtn)) {
            answer.setText("Correct!");
            chosen.setBackgroundColor(Color.GREEN);
            nbCor++;
        } else {
            chosen.setBackgroundColor(Color.GRAY);
            answer.setText(rightAnswerBtn.getText().toString() + "!");
            rightAnswerBtn.setBackgroundColor(Color.GREEN);
        }
        questionEnd();
    }

    public void questionEnd(){
        b1.setClickable(false);
        b2.setClickable(false);
        b3.setClickable(false);
        b4.setClickable(false);
        b5.setClickable(false);
        b6.setClickable(false);
        b7.setClickable(false);
        b8.setClickable(false);
        b9.setClickable(false);
        bNext.setClickable(true);
    }

    public void changeQuestion(View v){
        nbQuestion++;
        if(nbQuestion==11){
            Toast.makeText(getApplicationContext(),"You got "+nbCor+" correct answers out of 10",Toast.LENGTH_LONG).show();
            nbQuestion=1;
            nbCor=0;
        }
        bNext.setClickable(false);
        b1.setClickable(true);
        b2.setClickable(true);
        b3.setClickable(true);
        b4.setClickable(true);
        b5.setClickable(true);
        b6.setClickable(true);
        b7.setClickable(true);
        b8.setClickable(true);
        b9.setClickable(true);
        chosen.setBackgroundColor(getResources().getColor(R.color.def));
        rightAnswerBtn.setBackgroundColor(getResources().getColor(R.color.def));
        fillQuestion(choice);
    }

}
